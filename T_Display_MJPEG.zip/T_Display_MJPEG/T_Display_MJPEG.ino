#include <LittleFS.h>
#include <JPEGDEC.h>
#include <LovyanGFX.hpp>
#include "esp_heap_caps.h"
#include <WiFi.h>
#include <WebServer.h>

#define BUTTON_RESTART 0
#define BUTTON_BRIGHT 14

#define MAX_BUFFER_SIZE (64 * 1024)
#define READ_CHUNK_SIZE 4096
const char* VIDEO_FILE = "/video1.mjpeg";

#define FS_PARTITION_LABEL "spiffs"
#define TARGET_FPS 24
#define FRAME_INTERVAL_MS (1000 / TARGET_FPS)

static uint8_t brightness = 255;
static const uint8_t BRIGHT_MIN = 5;
static const uint8_t BRIGHT_MAX = 255;
static const uint8_t BRIGHT_STEP_TAP = 25;
static const uint8_t BRIGHT_STEP_RAMP = 4;
static const uint32_t HOLD_DELAY_MS = 350;
static const uint32_t RAMP_BASE_MS = 90;
static const uint32_t RAMP_MIN_MS = 12;

static volatile bool restartRequested = false;

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789 _panel;
  lgfx::Bus_Parallel8 _bus;
  lgfx::Light_PWM _light;
public:
  LGFX() {
    {
      auto cfg = _bus.config();
      cfg.freq_write = 20000000;
      cfg.pin_wr = 8;
      cfg.pin_rd = 9;
      cfg.pin_rs = 7;
      cfg.pin_d0 = 39;
      cfg.pin_d1 = 40;
      cfg.pin_d2 = 41;
      cfg.pin_d3 = 42;
      cfg.pin_d4 = 45;
      cfg.pin_d5 = 46;
      cfg.pin_d6 = 47;
      cfg.pin_d7 = 48;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg = _panel.config();
      cfg.pin_cs = 6;
      cfg.pin_rst = 5;
      cfg.pin_busy = -1;
      cfg.panel_width = 170;
      cfg.panel_height = 320;
      cfg.offset_x = 35;
      cfg.offset_y = 0;
      cfg.offset_rotation = 0;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits = 1;
      cfg.readable = false;
      cfg.invert = true;
      cfg.rgb_order = false;
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;
      _panel.config(cfg);
    }
    {
      auto cfg = _light.config();
      cfg.pin_bl = 38;
      cfg.invert = false;
      cfg.freq = 44100;
      cfg.pwm_channel = 7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }
    setPanel(&_panel);
  }
};

LGFX tft;
LGFX_Sprite canvas(&tft);
JPEGDEC jpeg;
File mjpegFile;
uint8_t* frameBuffer = nullptr;
uint8_t readBuffer[READ_CHUNK_SIZE];

static WebServer server(80);
static File uploadFile;

static const char UPLOAD_HTML[] PROGMEM = R"HTML(
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ESP32 Video Upload</title>
<style>
  :root{
    --bg:#0e1116; --card:#161b22; --line:#2a313a;
    --fg:#e6edf3; --mut:#8b949e; --acc:#3fb950; --acc2:#2ea043;
    --err:#f85149;
  }
  *{box-sizing:border-box}
  body{
    margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
    background:radial-gradient(1200px 600px at 50% -10%, #1b2430 0%, var(--bg) 60%);
    color:var(--fg);padding:20px;
  }
  .card{
    width:100%;max-width:520px;background:var(--card);border:1px solid var(--line);
    border-radius:16px;padding:26px 24px 22px;box-shadow:0 20px 60px rgba(0,0,0,.45);
  }
  .head{display:flex;align-items:center;gap:12px;margin-bottom:6px}
  .dot{width:10px;height:10px;border-radius:50%;background:var(--acc);
       box-shadow:0 0 10px var(--acc);animation:pulse 1.8s infinite}
  @keyframes pulse{50%{opacity:.35}}
  h1{font-size:19px;margin:0;font-weight:600;letter-spacing:.2px}
  .sub{color:var(--mut);font-size:13px;margin:4px 0 18px}
  code{background:#0b0f14;padding:2px 6px;border-radius:6px;font-size:12px;color:#79c0ff}

  #drop{
    position:relative;
    border:2px dashed var(--line);
    border-radius:14px;
    padding:32px 16px;
    text-align:center;
    cursor:pointer;
    transition:border-color .18s, background .18s;
    background:#0b0f14;
    user-select:none;
    -webkit-tap-highlight-color:transparent;
  }
  #drop:hover{border-color:#3d4551;background:#0d131a}
  #drop.over{border-color:var(--acc);background:#0f1c14}
  #drop.err{border-color:var(--err);background:#1a0d0d}
  #drop *{pointer-events:none}
  #drop svg{
    display:block;
    width:38px;height:38px;
    margin:0 auto 10px;
    stroke:#8b949e;
    fill:none;
    stroke-width:1.8;
    stroke-linecap:round;
    stroke-linejoin:round;
    transition:stroke .18s, transform .18s;
  }
  #drop:hover svg{stroke:#c9d1d9}
  #drop.over svg{stroke:var(--acc);transform:translateY(-3px)}
  #drop.err svg{stroke:var(--err)}
  .dtitle{font-size:14px;font-weight:600;color:var(--fg)}
  .dhint{font-size:12px;color:var(--mut);margin-top:4px}
  #file{display:none}

  .name{
    display:none;margin-top:14px;padding:10px 12px;background:#0b0f14;
    border:1px solid var(--line);border-radius:10px;font-size:13px;
    justify-content:space-between;gap:10px;align-items:center;
  }
  .name b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .name span{color:var(--mut);flex-shrink:0}

  .bar{
    margin-top:14px;height:8px;background:#0b0f14;border-radius:99px;
    overflow:hidden;border:1px solid var(--line);
  }
  .fill{height:100%;width:0%;background:linear-gradient(90deg,var(--acc),var(--acc2));
        border-radius:99px;transition:width .2s ease}
  .pct{font-size:12px;color:var(--mut);margin-top:6px;display:flex;justify-content:space-between}

  button{
    width:100%;margin-top:16px;padding:13px;font-size:15px;font-weight:600;
    color:#fff;background:var(--acc2);border:0;border-radius:11px;cursor:pointer;
    transition:.15s;letter-spacing:.2px;
  }
  button:hover:not(:disabled){background:var(--acc)}
  button:disabled{background:#30363d;color:var(--mut);cursor:not-allowed}

  .foot{margin-top:16px;font-size:11px;color:var(--mut);text-align:center}
</style>
</head>
<body>
<div class="card">
  <div class="head">
    <div class="dot"></div>
    <h1>ESP32 MJPEG Uploader</h1>
  </div>
  <p class="sub">Keo tha file <code>.mjpeg</code> vao o ben duoi roi bam Upload.</p>

  <div id="drop" role="button" tabindex="0" aria-label="Chon file mjpeg">
    <svg viewBox="0 0 24 24">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="17 8 12 3 7 8"/>
      <line x1="12" y1="3" x2="12" y2="15"/>
    </svg>
    <div class="dtitle" id="dtitle">Chon hoac keo file vao day</div>
    <div class="dhint" id="dhint">Chi nhan file .mjpeg - kich thuoc toi da theo dung luong FS</div>
  </div>
  <input type="file" id="file" accept=".mjpeg,.mjpg,video/*">

  <div class="name" id="nameBox">
    <b id="fname">-</b><span id="fsize">0 KB</span>
  </div>

  <div class="bar"><div class="fill" id="fill"></div></div>
  <div class="pct">
    <span id="pL">0%</span>
    <span id="pR">0 / 0 KB</span>
  </div>

  <button id="btn" disabled>Upload</button>

  <div class="foot">Ket noi WiFi <b>ESP32-Video</b> - mo <b>http://192.168.4.1</b></div>
</div>

<script>
var $ = function(id){ return document.getElementById(id); };
var drop=$('drop'), fileIn=$('file'), btn=$('btn');
var fill=$('fill'), pL=$('pL'), pR=$('pR');
var nameBox=$('nameBox'), fname=$('fname'), fsize=$('fsize');
var dtitle=$('dtitle'), dhint=$('dhint');
var currentFile=null;
var dragDepth = 0;

function fmt(b){
  if(b<1024) return b+' B';
  if(b<1048576) return (b/1024).toFixed(1)+' KB';
  return (b/1048576).toFixed(2)+' MB';
}
function setBtn(on, label){
  btn.disabled = !on;
  btn.textContent = label || 'Upload';
}

function pick(f){
  drop.classList.remove('err');
  if(!f) return;
  var ok = /\.(mjpeg|mjpg)$/i.test(f.name);
  if(!ok){
    drop.classList.add('err');
    dtitle.textContent = 'File khong dung dinh dang .mjpeg';
    dhint.textContent  = 'Vui long chon file .mjpeg / .mjpg';
    nameBox.style.display='none';
    setBtn(false);
    currentFile = null;
    return;
  }
  currentFile=f;
  dtitle.textContent = 'Da chon file';
  dhint.textContent  = 'Bam Upload de bat dau';
  fname.textContent=f.name;
  fsize.textContent=fmt(f.size);
  nameBox.style.display='flex';
  fill.style.width='0%'; pL.textContent='0%';
  pR.textContent='0 / '+fmt(f.size);
  setBtn(true);
}

drop.addEventListener('click', function(){ fileIn.click(); });
drop.addEventListener('keydown', function(e){
  if(e.key === 'Enter' || e.key === ' '){
    e.preventDefault();
    fileIn.click();
  }
});

['dragenter','dragover','dragleave','drop'].forEach(function(ev){
  document.addEventListener(ev, function(e){ e.preventDefault(); });
});

drop.addEventListener('dragenter', function(e){
  e.preventDefault();
  dragDepth++;
  drop.classList.add('over');
});
drop.addEventListener('dragover', function(e){
  e.preventDefault();
  e.dataTransfer.dropEffect = 'copy';
});
drop.addEventListener('dragleave', function(e){
  e.preventDefault();
  dragDepth = Math.max(0, dragDepth - 1);
  if(dragDepth === 0) drop.classList.remove('over');
});
drop.addEventListener('drop', function(e){
  e.preventDefault();
  dragDepth = 0;
  drop.classList.remove('over');
  var f = e.dataTransfer.files && e.dataTransfer.files[0];
  pick(f);
});

fileIn.addEventListener('change', function(){ pick(fileIn.files[0]); });

btn.addEventListener('click', function(){
  if(!currentFile) return;
  var fd = new FormData();
  fd.append('file', currentFile, currentFile.name);

  var x = new XMLHttpRequest();
  x.open('POST','/upload');

  x.upload.onprogress = function(ev){
    if(!ev.lengthComputable) return;
    var p = ev.loaded / ev.total * 100;
    fill.style.width = p.toFixed(1)+'%';
    pL.textContent = p.toFixed(1)+'%';
    pR.textContent = fmt(ev.loaded)+' / '+fmt(ev.total);
  };

  x.onloadstart = function(){ setBtn(false,'Dang gui...'); };
  x.onload = function(){
    fill.style.width='100%'; pL.textContent='100%';
    dtitle.textContent = 'Upload xong!';
    dhint.textContent  = 'ESP32 dang khoi dong lai...';
    setBtn(false,'Hoan tat');
  };
  x.onerror = function(){
    drop.classList.add('err');
    dtitle.textContent = 'Loi ket noi toi ESP32';
    dhint.textContent  = 'Kiem tra WiFi va thu lai';
    setBtn(true);
  };

  x.send(fd);
});
</script>
</body>
</html>)HTML";

int JPEGDraw(JPEGDRAW *pDraw) {
  canvas.pushImage(pDraw->x, pDraw->y, pDraw->iWidth, pDraw->iHeight,
                   (uint16_t*)pDraw->pPixels);
  return 1;
}

static inline void applyBrightness() {
  tft.setBrightness(brightness);
}

static void updateRestartButton() {
  static bool last = true;
  static uint32_t lastChange = 0;
  bool r = digitalRead(BUTTON_RESTART);
  uint32_t now = millis();
  if (r != last && (now - lastChange) > 30) {
    lastChange = now;
    if (r == LOW) {
      restartRequested = true;
    }
    last = r;
  }
}

static void updateBrightButton() {
  static bool last = true;
  static bool pressed = false;
  static uint32_t pressStart = 0;
  static uint32_t lastTick = 0;
  static uint16_t rampTick = 0;
  static int8_t dir = +1;

  bool r = digitalRead(BUTTON_BRIGHT);
  uint32_t now = millis();

  if (r == LOW && last == HIGH) {
    pressed = true;
    pressStart = now;
    lastTick = 0;
    rampTick = 0;
    dir = +1;
  }
  else if (r == HIGH && last == LOW && pressed) {
    if (rampTick == 0) {
      int nb = (int)brightness + BRIGHT_STEP_TAP;
      brightness = (uint8_t)constrain(nb, (int)BRIGHT_MIN, (int)BRIGHT_MAX);
      applyBrightness();
    }
    pressed = false;
  }
  else if (pressed && r == LOW) {
    if (now - pressStart >= HOLD_DELAY_MS) {
      uint32_t interval;
      if (rampTick == 0) {
        interval = 0;
      } else {
        interval = RAMP_BASE_MS;
        if (rampTick > 4) {
          uint32_t dec = (uint32_t)(rampTick - 4) * 6;
          interval = (dec >= (RAMP_BASE_MS - RAMP_MIN_MS))
                       ? RAMP_MIN_MS : (RAMP_BASE_MS - dec);
        }
      }

      if (lastTick == 0 || now - lastTick >= interval) {
        int nb = (int)brightness + dir * BRIGHT_STEP_RAMP;
        if (nb >= BRIGHT_MAX) { nb = BRIGHT_MAX; dir = -1; }
        if (nb <= BRIGHT_MIN) { nb = BRIGHT_MIN; dir = +1; }
        brightness = (uint8_t)nb;
        applyBrightness();
        lastTick = now;
        if (rampTick < 65000) rampTick++;
      }
    }
  }

  last = r;
}

static inline void updateButtons() {
  updateRestartButton();
  updateBrightButton();
}

static void handleRoot() {
  server.send_P(200, "text/html", UPLOAD_HTML);
}

static void handleUpload() {
  HTTPUpload& up = server.upload();
  if (up.status == UPLOAD_FILE_START) {
    Serial.printf("[UP] start: %s\n", up.filename.c_str());
    if (LittleFS.exists(VIDEO_FILE)) LittleFS.remove(VIDEO_FILE);
    uploadFile = LittleFS.open(VIDEO_FILE, FILE_WRITE);
  } else if (up.status == UPLOAD_FILE_WRITE) {
    if (uploadFile) uploadFile.write(up.buf, up.currentSize);
  } else if (up.status == UPLOAD_FILE_END) {
    if (uploadFile) uploadFile.close();
    Serial.printf("[UP] done: %u bytes\n", up.totalSize);
  }
}

static void handleUploadDone() {
  server.send(200, "text/plain", "OK");
  delay(500);
  ESP.restart();
}

static void runUploadMode() {
  tft.fillScreen(TFT_BLACK);

  if (!LittleFS.begin(false, "/littlefs", 10, FS_PARTITION_LABEL)) {
    tft.setCursor(8, 40);
    tft.print("Format FS...");
    if (!LittleFS.begin(true, "/littlefs", 10, FS_PARTITION_LABEL)) {
      tft.print("\nFS FAIL");
      while (1) delay(1000);
    }
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP("ESP32-Video");
  IPAddress ip = WiFi.softAPIP();

  tft.setCursor(5, 5);
  tft.setTextSize(1);
  tft.printf("WiFi: ESP32-Video\n");
  tft.setCursor(5, 15);
  tft.printf("Open: http://%s\n", ip.toString().c_str());

  Serial.printf("[UP] AP IP: %s\n", ip.toString().c_str());

  server.on("/", HTTP_GET, handleRoot);
  server.on("/upload", HTTP_POST, handleUploadDone, handleUpload);
  server.begin();

  while (true) {
    server.handleClient();
    delay(2);
  }
}

void setup() {
  Serial.begin(115200);
  Serial.setTxTimeoutMs(0);
  delay(500);

  pinMode(BUTTON_RESTART, INPUT_PULLUP);
  pinMode(BUTTON_BRIGHT, INPUT_PULLUP);

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  applyBrightness();

  if (digitalRead(BUTTON_RESTART) == LOW) {
    delay(50);
    if (digitalRead(BUTTON_RESTART) == LOW) {
      runUploadMode();
    }
  }

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(lgfx::middle_center);
  tft.setTextSize(2);
  tft.drawString("Thoai", tft.width() / 2, tft.height() / 2);
  delay(2000);

  tft.setTextDatum(lgfx::top_left);
  tft.fillScreen(TFT_BLACK);

  canvas.setPsram(false);
  canvas.setColorDepth(16);
  if (!canvas.createSprite(320, 170)) {
    canvas.setPsram(true);
    if (!canvas.createSprite(320, 170)) {
      tft.setTextSize(1);
      tft.drawString("Canvas Error", 5, 5);
      while (1) delay(100);
    }
  }

  frameBuffer = (uint8_t*)heap_caps_malloc(MAX_BUFFER_SIZE, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!frameBuffer) {
    frameBuffer = (uint8_t*)heap_caps_malloc(MAX_BUFFER_SIZE, MALLOC_CAP_SPIRAM);
    if (!frameBuffer) {
      tft.setTextSize(1);
      tft.drawString("RAM Error", 5, 5);
      while (1) delay(100);
    }
  }

  if (!LittleFS.begin(true, "/littlefs", 10, FS_PARTITION_LABEL)) {
    tft.setTextSize(1);
    tft.drawString("FS Error", 5, 5);
    while (1) delay(100);
  }
  Serial.printf("[OK] FS: %u / %u bytes (%.2f MB)\n",
                LittleFS.usedBytes(), LittleFS.totalBytes(),
                LittleFS.totalBytes() / 1048576.0f);

  if (!LittleFS.exists(VIDEO_FILE)) {
    tft.setTextSize(1);
    tft.drawString("No file", 5, 5);
    while (1) delay(100);
  }

  File f = LittleFS.open(VIDEO_FILE, FILE_READ);
  Serial.printf("[OK] Video: %u bytes\n", (uint32_t)f.size());
  f.close();
}

void playMJPEG() {
  if (mjpegFile) mjpegFile.close();
  mjpegFile = LittleFS.open(VIDEO_FILE, FILE_READ);
  if (!mjpegFile) {
    tft.setTextSize(1);
    tft.drawString("Open Error", 5, 5);
    return;
  }

  restartRequested = false;

  int bufIdx = 0;
  bool inFrame = false;
  uint8_t prevByte = 0;
  bool prevValid = false;
  uint32_t frameCount = 0, lastFps = millis();
  uint32_t lastFrameTime = millis();

  while (mjpegFile.available()) {
    updateButtons();
    if (restartRequested) return;

    int bytesRead = mjpegFile.read(readBuffer, READ_CHUNK_SIZE);
    if (bytesRead <= 0) break;

    for (int i = 0; i < bytesRead; i++) {
      uint8_t b = readBuffer[i];
      if (!inFrame) {
        if (prevValid && prevByte == 0xFF && b == 0xD8) {
          inFrame = true;
          bufIdx = 0;
          frameBuffer[bufIdx++] = 0xFF;
          frameBuffer[bufIdx++] = 0xD8;
        }
      } else {
        if (bufIdx < MAX_BUFFER_SIZE) frameBuffer[bufIdx++] = b;
        else { inFrame = false; bufIdx = 0; prevByte = b; prevValid = true; continue; }

        if (b == 0xD9 && bufIdx > 2 && frameBuffer[bufIdx - 2] == 0xFF) {
          inFrame = false;

          bool decoded = false;
          if (jpeg.openRAM(frameBuffer, bufIdx, JPEGDraw)) {
            jpeg.setPixelType(RGB565_BIG_ENDIAN);
            decoded = jpeg.decode(0, 0, 0);
            jpeg.close();
          }

          if (decoded) {
            canvas.pushSprite(0, 0);
            frameCount++;
          }

          uint32_t now = millis();
          uint32_t elapsed = now - lastFrameTime;
          if (elapsed < FRAME_INTERVAL_MS) {
            uint32_t target = now + (FRAME_INTERVAL_MS - elapsed);
            while ((int32_t)(millis() - target) < 0) {
              updateButtons();
              if (restartRequested) return;
              delay(1);
            }
          }
          lastFrameTime = millis();

          now = millis();
          if (now - lastFps >= 2000) {
            if (Serial.availableForWrite() > 80) {
              Serial.printf("[FPS] %.2f | BRIGHT: %u | SRAM: %u | PSRAM: %u | Blk: %u\n",
                frameCount * 1000.0f / (now - lastFps),
                brightness,
                heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                heap_caps_get_free_size(MALLOC_CAP_SPIRAM),
                heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL));
            }
            frameCount = 0;
            lastFps = now;
          }
          yield();
        }
      }
      prevByte = b;
      prevValid = true;
    }
  }
}

void loop() {
  playMJPEG();
  delay(restartRequested ? 50 : 300);
}